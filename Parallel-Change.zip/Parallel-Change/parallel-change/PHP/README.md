## Install dev dependencies
    composer install
    
## Run all code
    composer run
    
## Run only unit tests
    composer test