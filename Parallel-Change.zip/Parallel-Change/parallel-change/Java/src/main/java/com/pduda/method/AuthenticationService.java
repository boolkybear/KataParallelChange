package com.pduda.method;

public class AuthenticationService {
    public boolean isAuthenticated(int id) {
        return id == 12345;
    }
}
