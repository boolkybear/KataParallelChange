python3 method.py 
python3 field.py
python3 tests.py
