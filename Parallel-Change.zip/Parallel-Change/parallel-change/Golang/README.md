## Running tests

```bash
go test -v ./...
```
