import XCTest

class ShoppingCart {
    var prices: [Int] = []

    // the goal is to remove a field above, replacing with
    // `prices = []`

    func add(price: Int) {
        prices.append(price)
    }

    func numberOfProducts() -> Int {
        return prices.count
    }

    func calculateTotalPrice() -> Int {
        return prices.reduce(0, +)
    }

    func hasDiscount() -> Bool {
        let totalPrice = calculateTotalPrice()
        return totalPrice >= 100
    }
}


class SomeConsumer {
    func doStuff() {
        let shoppingCart = ShoppingCart()
        shoppingCart.add(price: 100)
        print("other consumer: \(shoppingCart.calculateTotalPrice())")
    }
}

class ShoppingCartMain: XCTestCase {
    func runExample() {
        let shoppingCart = ShoppingCart()
        shoppingCart.add(price: 10)
        print("number of products: \(shoppingCart.numberOfProducts())")
        print("total price: \(shoppingCart.calculateTotalPrice())")
        print("has discount: \(shoppingCart.hasDiscount())")
    }

    func testRunExample() {
        runExample()
    }
}
