import XCTest

enum Role {
    case admin
    case normal
}

class AuthenticationService {

    //
    // the goal is to replace the method above with this one:
    // func isAuthenticated(role, userId)
    //

    @discardableResult func isAuthenticated(role: Role, userId: Int) -> Bool {
        return userId == 12345
    }
}

class AuthenticationClient {
    let authenticationService: AuthenticationService

    init(authenticationService: AuthenticationService) {
        self.authenticationService = authenticationService
    }

    func run() {
        let authenticated = authenticationService.isAuthenticated(role: .admin, userId: 33)
        print("authenticated: \(authenticated)")
    }
}

class YetAnotherClient {
    func run() {
        AuthenticationService().isAuthenticated(role: .admin, userId: 100)
    }
}

class AuthenticationServiceMain: XCTestCase {
    func runExample() {
        let client = AuthenticationClient(authenticationService: AuthenticationService())
        client.run()
    }

    func testRunExample() {
        runExample()
    }
}
