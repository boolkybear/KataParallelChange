## Installing development dependencies

```bash
gem install rspec
```

## Running tests

```bash
./run.sh
```
